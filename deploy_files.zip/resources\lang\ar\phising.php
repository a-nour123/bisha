<?php

return array(
    'domains' => 'النطاقات',
);

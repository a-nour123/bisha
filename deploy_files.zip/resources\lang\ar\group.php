<?php

return array(
    'Name' => 'الاسم',
    'Actions' => 'الإجراءات',
);

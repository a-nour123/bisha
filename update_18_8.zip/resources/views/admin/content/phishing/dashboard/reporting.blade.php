@extends('admin/layouts/contentLayoutMaster')

@section('title', __('Phishing.domains'))

@section('vendor-style')
<link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/buttons.bootstrap5.min.css')) }}">

@endsection


@section('page-style')
<link rel="stylesheet" href="{{ asset('cdn/buttons.dataTables.min.css') }}">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<style>
    .page-wrapper.compact-small .page-body-wrapper .page-body {
        margin-left: 0 !important;
    }
    .page-wrapper .page-body-wrapper .page-body {
        padding: 0 !important;
    }

    .text-center {
        text-align: center;
    }

    .highcharts-credits {
        display: none;
    }

    /* DataTable Buttons Styling */
    button.dt-button, div.dt-button, a.dt-button, input.dt-button {
        border: 1px solid #18447a !important;
        background-color: #18447a !important;
        color: white !important;
        padding: 0.5em 1.5em !important;
        border-radius: 5px !important;
        margin: 0 2px !important;
        transition: all 0.3s ease !important;
    }

    button.dt-button:hover:not(.disabled),
    div.dt-button:hover:not(.disabled),
    a.dt-button:hover:not(.disabled),
    input.dt-button:hover:not(.disabled) {
        background-color: #5a2d7a !important;
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(68,34,92,0.3) !important;
    }

    /* Modal Improvements */
    .modal {
        overflow: hidden !important;
    }

    .modal.show {
        display: block !important;
    }

    body.modal-open {
        overflow: hidden !important;
        padding-right: 0 !important;
    }

    .modal-content {
        border-radius: 10px;
        border: none;
        box-shadow: 0 10px 40px rgba(0,0,0,0.2);
        max-height: 90vh;
        display: flex;
        flex-direction: column;
        overflow: hidden;
    }

    .modal-header {
        border-radius: 10px 10px 0 0;
        padding: 1.25rem 1.5rem;
        flex-shrink: 0;
        background-color: #18447a !important;
        color: white !important;
    }

    .modal-body {
        padding: 1.5rem;
        overflow-y: auto;
        overflow-x: hidden;
        max-height: calc(90vh - 150px);
        flex: 1 1 auto;
    }

    .modal-body .table-responsive {
        overflow-y: visible !important;
        overflow-x: auto;
    }

    .modal-footer {
        border-radius: 0 0 10px 10px;
        padding: 1rem 1.5rem;
        flex-shrink: 0;
    }

    /* Prevent page scroll when modal opens */
    .modal-backdrop {
        position: fixed;
        top: 0;
        left: 0;
        z-index: 1040;
        width: 100vw;
        height: 100vh;
        background-color: #000;
    }

    /* Modal Dialog Centering */
    .modal-dialog {
        margin: 1.75rem auto;
        display: flex;
        align-items: center;
        min-height: calc(100% - 3.5rem);
    }

    .modal-dialog-centered {
        min-height: calc(100% - 3.5rem);
        display: flex;
        align-items: center;
    }

    /* Card Improvements */
    .card {
        border-radius: 10px;
        transition: all 0.3s ease;
    }

    .card:hover {
        box-shadow: 0 5px 15px rgba(0,0,0,0.1) !important;
    }

    .card-header {
        border-radius: 10px 10px 0 0;
        font-weight: 600;
    }

    /* Table Improvements */
    .table thead th {
        font-weight: 600;
        text-transform: uppercase;
        font-size: 0.85rem;
        letter-spacing: 0.5px;
    }

    .table tbody tr {
        transition: all 0.2s ease;
    }

    .table tbody tr:hover {
        background-color: #f8f9fa;
        transform: scale(1.01);
    }

    /* Widget Cards */
    .widget-1 {
        transition: all 0.3s ease;
    }

    .widget-1:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 20px rgba(0,0,0,0.15) !important;
    }

    /* Nav Tabs */
    .nav-tabs .nav-link {
        border-radius: 5px 5px 0 0;
        transition: all 0.3s ease;
    }

    .nav-tabs .nav-link:hover {
        background-color: #f8f9fa;
    }

    .nav-tabs .nav-link.active {
        font-weight: 600;
    }

    /* Date Filter Form */
    #date-filter-form {
        background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        padding: 1.5rem;
        border-radius: 10px;
    }

    /* Chart Containers */
    #chart-container, #campaign-chart-container, #groups-chart-container, #employees-chart-container {
        min-height: 400px;
    }

    /* Summary Cards */
    .widget-round.primary .bg-round {
        background: linear-gradient(135deg, #18447a 0%, #18447a 100%);
    }

    .widget-round.success .bg-round {
        background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
    }

    .widget-round.warning .bg-round {
        background: linear-gradient(135deg, #22b9bb 0%, #198f91 100%);
    }

    .widget-round.danger .bg-round {
        background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
    }

    .widget-round.info .bg-round {
        background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
    }

    /* Responsive */
    @media (max-width: 768px) {
        .modal-dialog {
            margin: 0.5rem;
        }
        .widget-1 {
            margin-bottom: 1rem;
        }
    }
</style>
@endsection
@section('content')

    <div class="content-header row">
        <div class="content-header-left col-12 mb-2">

            <div class="row breadcrumbs-top  widget-grid">
                <div class="col-12">
                    <div class="page-title mt-2">
                        <div class="row">
                            <div class="col-sm-6 ps-0">
                                @if (@isset($breadcrumbs))
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}"
                                                style="display: flex;">
                                                <svg class="stroke-icon">
                                                    <use href="{{ asset('fonts/icons/icon-sprite.svg#stroke-home') }}">
                                                    </use>
                                                </svg></a></li>
                                        @foreach ($breadcrumbs as $breadcrumb)
                                            <li class="breadcrumb-item">
                                                @if (isset($breadcrumb['link']))
                                                    <a
                                                        href="{{ $breadcrumb['link'] == 'javascript:void(0)' ? $breadcrumb['link'] : url($breadcrumb['link']) }}">
                                                @endif
                                                {{ $breadcrumb['name'] }}
                                                @if (isset($breadcrumb['link']))
                                                    </a>
                                                @endif
                                            </li>
                                        @endforeach
                                    </ol>
                                @endisset
                        </div>

                    </div>
                </div>
            </div>

        </div>
    </div>



    <!-- Modal Campaign Employees -->
    <div class="modal fade" id="campaign-employees-data-modal" tabindex="-1" role="dialog" aria-labelledby="campaignEmployeesModalLabel" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
        <div class="modal-dialog modal-dialog-centered modal-fullscreen-lg-down modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="campaignEmployeesModalLabel">
                        <i class="fa fa-users me-2"></i>{{ __('phishing.Campaign_Employees') }}
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="{{ __('locale.Close') }}"></button>
                </div>
                <div class="modal-body p-3">
                    <div class="row">
                        <div class="col-12">
                            <div class="card border-0 shadow-sm">
                                <div class="card-body">
                                    <div class="row align-items-center mb-3">
                                        <div class="col-lg-12">
                                            <div id="dt-btns-employee" class="tableAdminOption"></div>
                                        </div>
                                    </div>
                                    <div class="table-responsive">
                                        <table class="table table-hover employee-dt-advanced-server-search" style="width:100%">
                                            <thead class="table-light sticky-top" style="background-color: #f8f9fa; z-index: 10;">
                                                <tr>
                                                    <th class="text-center">{{ __('phishing.Name') }}</th>
                                                    <th class="text-center">{{ __('phishing.Email') }}</th>
                                                    <th class="text-center">{{ __('phishing.Mail_Delivered') }}</th>
                                                    <th class="text-center">{{ __('phishing.Mail_Opened') }}</th>
                                                    <th class="text-center">{{ __('phishing.Clik_on_Link') }}</th>
                                                    <th class="text-center">{{ __('phishing.Download_File') }}</th>
                                                    <th class="text-center">{{ __('phishing.Submit_Data') }}</th>
                                                </tr>
                                            </thead>
                                            <tbody></tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="fa fa-times me-1"></i>{{ __('phishing.close') }}
                    </button>
                </div>
            </div>
        </div>
    </div>


    <!-- Modal Training Employees -->
    <div class="modal fade" id="training-employees-data-modal" tabindex="-1" role="dialog" aria-labelledby="trainingEmployeesModalLabel" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
        <div class="modal-dialog modal-dialog-centered modal-fullscreen-lg-down modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="trainingEmployeesModalLabel">
                        <i class="fa fa-graduation-cap me-2"></i>{{ __('phishing.Training_Employees') }}
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="{{ __('locale.Close') }}"></button>
                </div>
                <div class="modal-body p-3">
                    <div class="row">
                        <div class="col-12">
                            <div class="card border-0 shadow-sm">
                                <div class="card-body">
                                    <div class="row align-items-center mb-3">
                                        <div class="col-lg-12">
                                            <div id="dt-btns-training-employee" class="tableAdminOption"></div>
                                        </div>
                                    </div>
                                    <div class="table-responsive">
                                        <table class="table table-hover training-employee-dt-advanced-server-search" style="width:100%">
                                            <thead class="table-light sticky-top" style="background-color: #f8f9fa; z-index: 10;">
                                                <tr>
                                                    <th class="text-center">{{ __('phishing.Email') }}</th>
                                                    <th class="text-center">{{ __('phishing.Name') }}</th>
                                                    <th class="text-center">{{ __('phishing.Training_Name') }}</th>
                                                    <th class="text-center">{{ __('phishing.Date_Assigned') }}</th>
                                                    <th class="text-center">{{ __('phishing.Days_Until_Due') }}</th>
                                                    <th class="text-center">{{ __('phishing.Score') }}</th>
                                                    <th class="text-center">{{ __('phishing.PASSED') }}</th>
                                                    <th class="text-center">{{ __('phishing.FAILED') }}</th>
                                                    <th class="text-center">{{ __('phishing.PASSED_AFTER_OVERDUE') }}</th>
                                                    <th class="text-center">{{ __('phishing.OverDue') }}</th>
                                                </tr>
                                            </thead>
                                            <tbody></tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="fa fa-times me-1"></i>{{ __('phishing.close') }}
                    </button>
                </div>
            </div>
        </div>
    </div>


    <!-- Modal Employee Details -->
    <div class="modal fade" id="details-employees-data-modal" tabindex="-1" role="dialog" aria-labelledby="employeeDetailsModalLabel" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
        <div class="modal-dialog modal-dialog-centered modal-fullscreen-lg-down modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="employeeDetailsModalLabel">
                        <i class="fa fa-user-circle me-2"></i>{{ __('phishing.Employee_Details') }}
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="{{ __('locale.Close') }}"></button>
                </div>
                <div class="modal-body p-3">
                    <ul class="nav nav-tabs nav-tabs-custom mb-3" id="employeeDetailsTab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="employee-campaign-tab" data-bs-toggle="tab" data-bs-target="#employee-campaign" type="button" role="tab">
                                <i class="fa fa-envelope me-1"></i>{{ __('phishing.Phishing_Campaigns') }}
                            </button>
                        </li>
                    </ul>
                    <div class="tab-content" id="employeeDetailsTabContent">
                        <div class="tab-pane fade show active" id="employee-campaign" role="tabpanel">
                            <div class="card border-0 shadow-sm">
                                <div class="card-body">
                                    <div class="row align-items-center mb-3">
                                        <div class="col-lg-12">
                                            <div id="dt-btns-employee-details-phishing" class="tableAdminOption"></div>
                                        </div>
                                    </div>
                                    <div class="table-responsive">
                                        <table class="table table-hover employee-details-phishing-dt-advanced-server-search" style="width:100%">
                                            <thead class="table-light sticky-top" style="background-color: #f8f9fa; z-index: 10;">
                                                <tr>
                                                    <th class="text-center">{{ __('phishing.CAMPAIGN_NAME') }}</th>
                                                    <th class="text-center">{{ __('phishing.Mail_Template') }}</th>
                                                    <th class="text-center">{{ __('phishing.Mail_Opened') }}</th>
                                                    <th class="text-center">{{ __('phishing.Link_Clicked') }}</th>
                                                    <th class="text-center">{{ __('phishing.File_Downloaded') }}</th>
                                                    <th class="text-center">{{ __('phishing.Data_Submitted') }}</th>
                                                </tr>
                                            </thead>
                                            <tbody></tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="fa fa-times me-1"></i>{{ __('phishing.close') }}
                    </button>
                </div>
            </div>
        </div>
    </div>




    {{-- Dashboard --}}

    <div class="page-wrapper" id="pageWrapper">
        <!-- Page Body Start-->
        <div class="page-body-wrapper">
          <!-- Page Sidebar Ends-->
          <div class="page-body">
            <div class="container-fluid"></div>
            <!-- Container-fluid starts-->
            <div class="container-fluid dashboard_default">
              <div class="row widget-grid">

                {{-- Date Range Filter --}}
                <div class="col-12 mb-3">
                    <div class="card">
                        <div class="card-body">
                            <form method="GET" action="{{ route('admin.phishing.reporting') }}" id="date-filter-form" class="row g-3 align-items-end">
                                <div class="col-md-3">
                                    <label for="start_date" class="form-label">{{ __('phishing.Start_Date') }}</label>
                                    <input type="date" name="start_date" id="start_date" class="form-control"
                                           value="{{ request('start_date', \Carbon\Carbon::now()->subYear()->format('Y-m-d')) }}">
                                </div>
                                <div class="col-md-3">
                                    <label for="end_date" class="form-label">{{ __('phishing.End_Date') }}</label>
                                    <input type="date" name="end_date" id="end_date" class="form-control"
                                           value="{{ request('end_date', \Carbon\Carbon::now()->format('Y-m-d')) }}">
                                </div>
                                <div class="col-md-3">
                                    <button type="submit" class="btn btn-primary">{{ __('phishing.Filter') }}</button>
                                    <a href="{{ route('admin.phishing.reporting') }}" class="btn btn-secondary">{{ __('phishing.Reset') }}</a>
                                </div>
                            </form>

                            <script>
                                // Reload DataTables when form is submitted
                                $(document).ready(function() {
                                    $('#date-filter-form').on('submit', function(e) {
                                        // DataTables will automatically reload with new filter parameters via AJAX data function
                                        setTimeout(function() {
                                            if ($.fn.DataTable.isDataTable('.active-phishing-dt-advanced-server-search')) {
                                                $('.active-phishing-dt-advanced-server-search').DataTable().ajax.reload(null, false);
                                            }
                                            if ($.fn.DataTable.isDataTable('.archived-phishing-dt-advanced-server-search')) {
                                                $('.archived-phishing-dt-advanced-server-search').DataTable().ajax.reload(null, false);
                                            }
                                            if ($.fn.DataTable.isDataTable('.active-training-dt-advanced-server-search')) {
                                                $('.active-training-dt-advanced-server-search').DataTable().ajax.reload(null, false);
                                            }
                                            if ($.fn.DataTable.isDataTable('.archived-training-dt-advanced-server-search')) {
                                                $('.archived-training-dt-advanced-server-search').DataTable().ajax.reload(null, false);
                                            }
                                            if ($.fn.DataTable.isDataTable('.employee-statistics-dt-advanced-server-search')) {
                                                $('.employee-statistics-dt-advanced-server-search').DataTable().ajax.reload(null, false);
                                            }
                                        }, 500);
                                    });
                                });
                            </script>
                        </div>
                    </div>
                </div>




                <div class="col-xxl-12 col-xl-12 col-md-12 box-col-12">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true"> {{ __('phishing.Phishing_Statistics') }}  </button>
                        </li>

                        {{--  <li class="nav-item" role="presentation">
                            <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false"> {{ __('phishing.Training_Information') }}</button>
                        </li>  --}}

                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="ciso-phishing-tab" data-bs-toggle="tab" data-bs-target="#ciso-phishing" type="button" role="tab" aria-controls="ciso-phishing" aria-selected="false">{{ __('phishing.CISO_Phishing_Report') }} </button>
                        </li>

                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="employee-tab" data-bs-toggle="tab" data-bs-target="#employee" type="button" role="tab" aria-controls="employee" aria-selected="false">{{ __('phishing.Employee_Information') }} </button>
                        </li>
                    </ul>
                </div>


                <div class="tab-content my-3" id="myTabContent">
                    <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">

                        {{-- Summary Statistics Cards --}}
                        <div class="row mb-4">
                            <div class="col-xl-3 col-md-6 mb-3">
                                <div class="card widget-1 border-0 shadow-sm">
                                    <div class="card-body">
                                        <div class="widget-content">
                                            <div class="widget-round primary">
                                                <div class="bg-round">
                                                    <i class="fa fa-envelope-open-text"></i>
                                                    <svg class="half-circle svg-fill">
                                                        <use href="{{ asset('fonts/icons/icon-sprite.svg#halfcircle') }}"></use>
                                                    </svg>
                                                </div>
                                            </div>
                                            <div>
                                                <h4>{{ $mail_statistic->sum('mails_opened') }}</h4>
                                                <span class="f-light">{{ __('phishing.Total_Emails_Opened') }}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6 mb-3">
                                <div class="card widget-1 border-0 shadow-sm">
                                    <div class="card-body">
                                        <div class="widget-content">
                                            <div class="widget-round success">
                                                <div class="bg-round">
                                                    <i class="fa fa-mouse-pointer"></i>
                                                    <svg class="half-circle svg-fill">
                                                        <use href="{{ asset('fonts/icons/icon-sprite.svg#halfcircle') }}"></use>
                                                    </svg>
                                                </div>
                                            </div>
                                            <div>
                                                <h4>{{ $mail_statistic->sum('clicked_link') }}</h4>
                                                <span class="f-light">{{ __('phishing.Total_Links_Clicked') }}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6 mb-3">
                                <div class="card widget-1 border-0 shadow-sm">
                                    <div class="card-body">
                                        <div class="widget-content">
                                            <div class="widget-round warning">
                                                <div class="bg-round">
                                                    <i class="fa fa-file-download"></i>
                                                    <svg class="half-circle svg-fill">
                                                        <use href="{{ asset('fonts/icons/icon-sprite.svg#halfcircle') }}"></use>
                                                    </svg>
                                                </div>
                                            </div>
                                            <div>
                                                <h4>{{ $mail_statistic->sum('mails_downloaded') }}</h4>
                                                <span class="f-light">{{ __('phishing.Total_Files_Downloaded') }}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-md-6 mb-3">
                                <div class="card widget-1 border-0 shadow-sm">
                                    <div class="card-body">
                                        <div class="widget-content">
                                            <div class="widget-round danger">
                                                <div class="bg-round">
                                                    <i class="fa fa-paper-plane"></i>
                                                    <svg class="half-circle svg-fill">
                                                        <use href="{{ asset('fonts/icons/icon-sprite.svg#halfcircle') }}"></use>
                                                    </svg>
                                                </div>
                                            </div>
                                            <div>
                                                <h4>{{ $mail_statistic->sum('mails_submitted') }}</h4>
                                                <span class="f-light">{{ __('phishing.Total_Forms_Submitted') }}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card border-0 shadow-sm mb-4">
                            <div class="card-header bg-white border-bottom pb-3">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h4 class="mb-0">
                                        <i class="fa fa-chart-line me-2 text-primary"></i>
                                        {{ __('phishing.Phishing_Emails_Delivered') }}
                                    </h4>
                                    <span class="badge bg-primary">
                                        @if(request('start_date') && request('end_date'))
                                            {{ \Carbon\Carbon::parse(request('start_date'))->format('Y-m-d') }} - {{ \Carbon\Carbon::parse(request('end_date'))->format('Y-m-d') }}
                                        @else
                                            {{ __('phishing.Past_Year') }}
                                        @endif
                                    </span>
                                </div>
                            </div>
                            <div class="card-body p-4">
                                <div id="chart-container" style="min-height: 400px;"></div>
                            </div>
                        </div>

                        {{-- Campaign Statistics --}}
                        <div class="card border-0 shadow-sm mb-4">
                            <div class="card-header bg-white border-bottom pb-3">
                                <h4 class="mb-0">
                                    <i class="fa fa-bullhorn me-2 text-success"></i>
                                    {{ __('phishing.Campaigns_Statistic') }}
                                </h4>
                            </div>
                            <div class="card-body p-4">
                                <div id="campaign-chart-container" style="min-height: 400px;"></div>
                            </div>
                        </div>

                        {{-- Groups Statistics --}}
                        <div class="card border-0 shadow-sm mb-4">
                            <div class="card-header bg-white border-bottom pb-3">
                                <h4 class="mb-0">
                                    <i class="fa fa-users me-2 text-info"></i>
                                    {{ __('phishing.Groups_Statistic') }}
                                </h4>
                            </div>
                            <div class="card-body p-4">
                                <div id="groups-chart-container" style="min-height: 400px;"></div>
                            </div>
                        </div>

                        {{-- Employees Statistics --}}
                        <div class="card border-0 shadow-sm mb-4">
                            <div class="card-header bg-white border-bottom pb-3">
                                <h4 class="mb-0">
                                    <i class="fa fa-user-friends me-2 text-warning"></i>
                                    {{ __('phishing.Employees_Statistic') }}
                                </h4>
                            </div>
                            <div class="card-body p-4">
                                <div id="employees-chart-container" style="min-height: 400px;"></div>
                            </div>
                        </div>



                        {{-- Active Campaigns Table --}}
                        <div class="card border-0 shadow-sm mb-4">
                            <div class="card-header bg-white border-bottom pb-3">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h4 class="mb-0">
                                        <i class="fa fa-list-alt me-2 text-danger"></i>
                                        {{ __('phishing.Active_Campaigns') }}
                                    </h4>
                                    <span class="badge bg-danger">{{ $campaignChart->count() }}</span>
                                </div>
                            </div>
                            <div class="card-body p-0">
                                <div class="table-responsive">
                                    <div class="p-3">
                                        <div id="dt-btns-active-phishing" class="tableAdminOption"></div>
                                    </div>
                                    <table class="table table-hover mb-0 active-phishing-dt-advanced-server-search" style="width:100%">
                                        <thead class="table-light">
                                            <tr>
                                                <th class="text-center">#</th>
                                                <th class="text-center">{{ __('phishing.CAMPAIGN_NAME') }}</th>
                                                <th class="text-center">{{ __('phishing.STATUS') }}</th>
                                                <th class="text-center">{{ __('phishing.campaign_type') }}</th>
                                                <th class="text-center">{{ __('phishing.SCEDULE_DATE') }}</th>
                                                <th class="text-center">{{ __('phishing.EMAIL_DELIVERED') }}</th>
                                                <th class="text-center">{{ __('phishing.EMAIL_OPENED') }}</th>
                                                <th class="text-center">{{ __('phishing.EMAIL_DOWNLOAD_FILE') }}</th>
                                                <th class="text-center">{{ __('phishing.EMAIL_SUBMIT_DATA') }}</th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <div class="card invoice-card">
                            {{--  <div class="card-header pb-0">
                              <h3 class="my-3">Archived Campaigns</h3>
                            </div>
                            <div class="card-body transaction-card">
                              <div class="table-responsive theme-scrollbar">
                                <div class="row align-items-center text-center text-md-left">
                                    <div class="col-lg-12 mt-lg-0 mt-3">
                                        <div id="dt-btns-archived-phishing" class="tableAdminOption">
                                        </div>
                                    </div>
                                </div>

                                <table class="display archived-phishing-dt-advanced-server-search" id="recent-order-archived-phishing" style="width:100%">
                                  <thead>
                                    <tr>
                                        <th class="text-center">#</th>
                                        <th class="text-center">{{ __('phishing.CAMPAIGN_NAME') }}</th>
                                        <th class="text-center">{{ __('phishing.STATUS') }}</th>
                                        <th class="text-center">{{ __('phishing.CAMPAIGN_TYPE') }}</th>

                                  {{--  </tbody>
                                </table>  --}}
                              {{--  </div>
                            </div>  --}}
                        </div>
                    </div>

                    {{-- Training Information --}}
                    <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                        <div class="card">
                            <div class="card-header pb-0">
                              <h3 class="m-0">{{ __('phishing.Trainings_Assigned') }} ({{ __('phishing.Past_Year') }})</h3>
                            </div>
                            <div class="card-body row p-2">
                              <div class="col-lg-12">
                                <div id="training-chart-container"></div>
                              </div>
                            </div>
                        </div>

                        {{-- Active Training Campaigns --}}
                        <div class="card invoice-card">
                            <div class="card-header pb-0">
                              <h3 class="my-3">{{ __('phishing.Active_Training_Campaigns') }}</h3>
                            </div>
                            <div class="card-body transaction-card">
                              <div class="table-responsive theme-scrollbar">

                                <div class="row align-items-center text-center text-md-left">
                                    <div class="col-lg-12 mt-lg-0 mt-3">
                                        <div id="dt-btns-active-training" class="tableAdminOption">
                                        </div>
                                    </div>
                                </div>

                                <table class="display active-training-dt-advanced-server-search" id="recent-order-active-training" style="width:100%">
                                  <thead>
                                    <tr>
                                        <th class="text-center">{{ __('phishing.ID') }}</th>
                                        <th class="text-center">{{ __('phishing.campaign_name') }}</th>
                                        <th class="text-center">{{ __('phishing.STATUS') }} </th>
                                        <th class="text-center">{{ __('phishing.campaign_type') }}</th>
                                        <th class="text-center">{{ __('phishing.SCHEDULED_DATE') }}</th>
                                        <th class="text-center">{{ __('phishing.EMPLOYEE_COUNT') }} </th>
                                        <th class="text-center">{{ __('phishing.ASSSIGNED') }} </th>
                                        <th class="text-center">{{ __('phishing.PASSED') }} </th>
                                        <th class="text-center">{{ __('phishing.FAILED') }} </th>
                                        <th class="text-center">{{ __('phishing.PASSED_AFTER_OVERDUE') }} </th>
                                        <th class="text-center">{{ __('phishing.OVERDUE') }} </th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                  </tbody>
                                </table>
                              </div>
                            </div>
                        </div>

                        {{-- Archived Training Campaigns --}}
                        <div class="card invoice-card">
                            <div class="card-header pb-0">
                              <h3 class="my-3">{{ __('phishing.Archived_Training_Campaigns') }}</h3>
                            </div>
                            <div class="card-body transaction-card">
                              <div class="table-responsive theme-scrollbar">

                                <div class="row align-items-center text-center text-md-left">
                                    <div class="col-lg-12 mt-lg-0 mt-3">
                                        <div id="dt-btns-archived-training" class="tableAdminOption">
                                        </div>
                                    </div>
                                </div>

                                <table class="display archived-training-dt-advanced-server-search" id="recent-order-archived-training" style="width:100%">
                                  <thead>
                                    <tr>
                                        <th class="text-center">{{ __('phishing.ID') }}</th>
                                        <th class="text-center">{{ __('phishing.campaign_name') }}</th>
                                        <th class="text-center">{{ __('phishing.STATUS') }} </th>
                                        <th class="text-center">{{ __('phishing.campaign_type') }}</th>
                                        <th class="text-center">{{ __('phishing.SCHEDULED_DATE') }}</th>
                                        <th class="text-center">{{ __('phishing.EMPLOYEE_COUNT') }} </th>
                                        <th class="text-center">{{ __('phishing.ASSSIGNED') }} </th>
                                        <th class="text-center">{{ __('phishing.PASSED') }} </th>
                                        <th class="text-center">{{ __('phishing.FAILED') }} </th>
                                        <th class="text-center">{{ __('phishing.PASSED_AFTER_OVERDUE') }} </th>
                                        <th class="text-center">{{ __('phishing.OVERDUE') }} </th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                  </tbody>
                                </table>
                              </div>
                            </div>
                        </div>


                    </div>

                    {{-- CISO Phishing Report --}}
                    <div class="tab-pane fade" id="ciso-phishing" role="tabpanel" aria-labelledby="ciso-phishing-tab">
                        {{-- Summary Statistics --}}
                        <div class="row mb-4">
                            <div class="col-xl-3 col-md-6 mb-3">
                                <div class="card widget-1 border-0 shadow-sm">
                                    <div class="card-body">
                                        <div class="widget-content">
                                            <div class="widget-round primary">
                                                <div class="bg-round">
                                                    <i class="fa fa-bullhorn"></i>
                                                    <svg class="half-circle svg-fill">
                                                        <use href="{{ asset('fonts/icons/icon-sprite.svg#halfcircle') }}"></use>
                                                    </svg>
                                                </div>
                                            </div>
                                            <div>
                                                <h4>{{ $cisoTotalCampaigns }}</h4>
                                                <span class="f-light">{{ __('phishing.Phishing_Campaigns_Count') }}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-md-6 mb-3">
                                <div class="card widget-1 border-0 shadow-sm">
                                    <div class="card-body">
                                        <div class="widget-content">
                                            <div class="widget-round success">
                                                <div class="bg-round">
                                                    <i class="fa fa-envelope"></i>
                                                    <svg class="half-circle svg-fill">
                                                        <use href="{{ asset('fonts/icons/icon-sprite.svg#halfcircle') }}"></use>
                                                    </svg>
                                                </div>
                                            </div>
                                            <div>
                                                <h4>{{ $cisoTotalEmails }}</h4>
                                                <span class="f-light">{{ __('phishing.Total_Emails_Delivered') }}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-md-6 mb-3">
                                <div class="card widget-1 border-0 shadow-sm">
                                    <div class="card-body">
                                        <div class="widget-content">
                                            <div class="widget-round warning">
                                                <div class="bg-round">
                                                    <i class="fa fa-users"></i>
                                                    <svg class="half-circle svg-fill">
                                                        <use href="{{ asset('fonts/icons/icon-sprite.svg#halfcircle') }}"></use>
                                                    </svg>
                                                </div>
                                            </div>
                                            <div>
                                                <h4>{{ $cisoTotalEmployees }}</h4>
                                                <span class="f-light">{{ __('phishing.Total_Employees_Targeted') }}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-md-6 mb-3">
                                <div class="card widget-1 border-0 shadow-sm">
                                    <div class="card-body">
                                        <div class="widget-content">
                                            <div class="widget-round info">
                                                <div class="bg-round">
                                                    <i class="fa fa-mouse-pointer"></i>
                                                    <svg class="half-circle svg-fill">
                                                        <use href="{{ asset('fonts/icons/icon-sprite.svg#halfcircle') }}"></use>
                                                    </svg>
                                                </div>
                                            </div>
                                            <div>
                                                <h4>{{ $cisoUsersClicked }}</h4>
                                                <span class="f-light">{{ __('phishing.Users_Who_Clicked') }}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-md-6 mb-3">
                                <div class="card widget-1 border-0 shadow-sm">
                                    <div class="card-body">
                                        <div class="widget-content">
                                            <div class="widget-round danger">
                                                <div class="bg-round">
                                                    <i class="fa fa-file-download"></i>
                                                    <svg class="half-circle svg-fill">
                                                        <use href="{{ asset('fonts/icons/icon-sprite.svg#halfcircle') }}"></use>
                                                    </svg>
                                                </div>
                                            </div>
                                            <div>
                                                <h4>{{ $cisoUsersDownloaded }}</h4>
                                                <span class="f-light">{{ __('phishing.Users_Who_Downloaded') }}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-3 col-md-6 mb-3">
                                <div class="card widget-1 border-0 shadow-sm">
                                    <div class="card-body">
                                        <div class="widget-content">
                                            <div class="widget-round secondary">
                                                <div class="bg-round">
                                                    <i class="fa fa-percentage"></i>
                                                    <svg class="half-circle svg-fill">
                                                        <use href="{{ asset('fonts/icons/icon-sprite.svg#halfcircle') }}"></use>
                                                    </svg>
                                                </div>
                                            </div>
                                            <div>
                                                <h4>{{ $cisoTotalEmployees > 0 ? number_format(($cisoUsersClicked / $cisoTotalEmployees) * 100, 2) : 0 }}%</h4>
                                                <span class="f-light">{{ __('phishing.Click_Rate') }}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {{-- Campaigns Table --}}
                        <div class="col-12">
                            <div class="card border-0 shadow-sm">
                                <div class="card-header bg-white border-bottom pb-3">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <h4 class="mb-0">
                                            <i class="fa fa-list-alt me-2 text-primary"></i>
                                            {{ __('phishing.Campaigns_Statistic') }}
                                        </h4>
                                        <span class="badge bg-primary">{{ $cisoPhishingCampaigns->count() }}</span>
                                    </div>
                                </div>
                                <div class="card-body p-0">
                                    <div class="table-responsive">
                                        <table class="table table-hover mb-0">
                                            <thead class="table-light">
                                                <tr>
                                                    <th class="text-center">{{ __('phishing.CAMPAIGN_NAME') }}</th>
                                                    <th class="text-center">{{ __('phishing.Total_Emails_Delivered') }}</th>
                                                    <th class="text-center">{{ __('phishing.Total_Employees_Targeted') }}</th>
                                                    <th class="text-center">{{ __('phishing.clicked_link_count') }}</th>
                                                    <th class="text-center">{{ __('phishing.file_downloaded_count') }}</th>
                                                    <th class="text-center">{{ __('phishing.Click_Rate') }}</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @forelse($cisoPhishingCampaigns as $campaign)
                                                    @php
                                                        $clickRate = $campaign->deliverd_employees_count > 0
                                                            ? number_format(($campaign->clicked_trackings_count / $campaign->deliverd_employees_count) * 100, 2)
                                                            : 0;
                                                    @endphp
                                                    <tr>
                                                        <td class="text-center fw-bold">{{ $campaign->campaign_name }}</td>
                                                        <td class="text-center">
                                                            <span class="badge bg-info">{{ $campaign->deliverd_email_templates_count }}</span>
                                                        </td>
                                                        <td class="text-center">
                                                            <span class="badge bg-warning">{{ $campaign->deliverd_employees_count }}</span>
                                                        </td>
                                                        <td class="text-center">
                                                            <span class="badge bg-success">{{ $campaign->clicked_trackings_count }}</span>
                                                        </td>
                                                        <td class="text-center">
                                                            <span class="badge bg-danger">{{ $campaign->downloaded_trackings_count }}</span>
                                                        </td>
                                                        <td class="text-center">
                                                            <div class="d-flex align-items-center justify-content-center">
                                                                <span class="badge {{ $clickRate >= 50 ? 'bg-danger' : ($clickRate >= 30 ? 'bg-warning' : 'bg-success') }} me-2">
                                                                    {{ $clickRate }}%
                                                                </span>
                                                                <div class="progress" style="width: 100px; height: 8px;">
                                                                    <div class="progress-bar {{ $clickRate >= 50 ? 'bg-danger' : ($clickRate >= 30 ? 'bg-warning' : 'bg-success') }}"
                                                                         role="progressbar"
                                                                         style="width: {{ $clickRate }}%"
                                                                         aria-valuenow="{{ $clickRate }}"
                                                                         aria-valuemin="0"
                                                                         aria-valuemax="100"></div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                @empty
                                                    <tr>
                                                        <td colspan="6" class="text-center py-4">
                                                            <i class="fa fa-inbox fa-3x text-muted mb-2"></i>
                                                            <p class="text-muted">{{ __('locale.NoDataAvailable') }}</p>
                                                        </td>
                                                    </tr>
                                                @endforelse
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    {{-- Employee Information --}}
                    <div class="tab-pane fade" id="employee" role="tabpanel" aria-labelledby="employee-tab">
                        <div class="card border-0 shadow-sm">
                            <div class="card-header bg-white border-bottom pb-3">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h4 class="mb-0">
                                        <i class="fa fa-user-shield me-2 text-primary"></i>
                                        {{ __('phishing.Employee_Statistics') }}
                                    </h4>
                                    <span class="badge bg-primary">{{ $employees_statistic->count() }}</span>
                                </div>
                            </div>
                            <div class="card-body p-0">
                                <div class="table-responsive">
                                    <div class="p-3">
                                        <div id="dt-btns-employee-statistics" class="tableAdminOption"></div>
                                    </div>
                                    <table class="table table-hover mb-0 employee-statistics-dt-advanced-server-search" style="width:100%">
                                        <thead class="table-light">
                                            <tr>
                                                <th class="text-center">{{ __('phishing.ID') }}</th>
                                                <th class="text-center">{{ __('phishing.email') }}</th>
                                                <th class="text-center">{{ __('phishing.name') }}</th>
                                                <th class="text-center">{{ __('phishing.RISK_SCORE') }}</th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

              </div>
            </div>
          </div>
        </div>
    </div>
@endsection

@section('vendor-script')
@endsection

@section('page-script')
{{--  <script src="{{ asset('js/scripts/highcharts/highcharts.js') }}"></script>  --}}
<script src="{{ asset('js/scripts/config.js') }}"></script>
<script src="{{ asset('new_d/js/datatable/datatables/jquery.dataTables.min.js')}}"></script>
<script src="{{ asset('new_d/js/datatable/datatables/datatable.custom.js')}}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/datatables.buttons.min.js')) }}"></script>
{{-- DataTable Buttons Excel - Pdf - Print -.... --}}
<script src="{{ asset(mix('vendors/js/tables/datatable/jszip.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/pdfmake.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/vfs_fonts.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/buttons.html5.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/buttons.print.min.js')) }}"></script>
<script src="{{ asset('ajax-files/asset_management/asset/index.js') }}"></script>
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>
<script src="https://code.highcharts.com/modules/offline-exporting.js"></script>

<script>
    (function () {
        if (typeof Highcharts !== 'undefined') {
            try {
                Highcharts.setOptions({
                    global: {
                        useUTC: false
                    },
                    lang: {
                        months: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
                        shortMonths: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                        weekdays: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
                        decimalPoint: '.',
                        thousandsSep: ','
                    }
                });
            } catch (e) {
                console.warn('Highcharts locale setup warning (phishing reporting):', e);
            }
        }
    })();
</script>

<script>
    document.addEventListener('DOMContentLoaded', function () {

        // ************************************* Phishing charts *************************************
        Highcharts.chart('chart-container', {
            chart: {
                type: 'column'
            },
            title: {
                text: '{{ __('phishing.Campaign_Mails_Statistic') }}'
            },
            xAxis: {
                categories: {!! $labels->toJson(JSON_UNESCAPED_UNICODE) !!},
                labels: {
                    formatter: function () {
                        return this.value;
                    }
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: '{{ __('phishing.Mail_Statistic') }}'
                },
                stackLabels: {
                    enabled: true,
                    style: {
                        fontWeight: 'bold',
                        color: ( // theme
                            Highcharts.defaultOptions.title.style &&
                            Highcharts.defaultOptions.title.style.color
                        ) || 'gray'
                    }
                }
            },
            legend: {
                align: 'right',
                x: -30,
                verticalAlign: 'top',
                y: 25,
                floating: true,
                backgroundColor: Highcharts.defaultOptions.legend.backgroundColor || 'white',
                borderColor: '#CCC',
                borderWidth: 1,
                shadow: false
            },
            tooltip: {
                headerFormat: '<b>{point.x}</b>',
                pointFormat: ': {point.stackTotal}'
            },
            plotOptions: {
                column: {
                    stacking: null,
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            series: [



                {
                    name: '{{ __('phishing.opened_count') }}',
                    color: 'green',
                    data: {!! $opened_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },

                {
                    name: '{{ __('phishing.clicked_link_count') }}',
                    color: 'Black',
                    data: {!! $clicked_link_count->toJson(JSON_UNESCAPED_UNICODE) !!}

                },

                {
                    name: '{{ __('phishing.form_submited_count') }}',
                    color: 'red',
                    data: {!! $submited_count->toJson(JSON_UNESCAPED_UNICODE) !!}

                },

                {
                    name: '{{ __('phishing.file_downloaded_count') }}',
                    color: 'yellow',
                    data: {!! $downloaded_count->toJson(JSON_UNESCAPED_UNICODE) !!}

                },
            ],

        })

        // #-2 Campaign chart
        Highcharts.chart('campaign-chart-container', {
            chart: {
                type: 'column'
            },
            title: {
                text: '{{ __('phishing.Campaign_Mails_And_Employee_Statistic') }}',
                style: {
                    marginBottom: '120px',
                }
            },
            xAxis: {
                categories: {!! $campaig_labels->toJson(JSON_UNESCAPED_UNICODE) !!},
                labels: {
                    formatter: function () {
                        return this.value;
                    }
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: '{{ __('phishing.Campaign_Mails_And_Employee_Statistic') }}'
                },
                stackLabels: {
                    enabled: true,
                    style: {
                        fontWeight: 'bold',
                        color: ( // theme
                            Highcharts.defaultOptions.title.style &&
                            Highcharts.defaultOptions.title.style.color
                        ) || 'gray'
                    }
                }
            },
            legend: {
                align: 'right',
                x: -30,
                verticalAlign: 'top',
                y: 25,
                floating: true,
                backgroundColor: Highcharts.defaultOptions.legend.backgroundColor || 'white',
                borderColor: '#CCC',
                borderWidth: 1,
                shadow: false
            },
            tooltip: {
                headerFormat: '<b>{point.x}</b>',
                pointFormat: ': {point.stackTotal}'
            },
            plotOptions: {
                column: {
                    stacking: null,
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            series: [
                {
                    name: '{{ __('phishing.Deliverd_email') }}',
                    color: 'green',
                    data: {!! $deliverd_email_templates_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },

                {
                    name: ' {{ __('phishing.Deliverd_employees') }}',
                    color: '#0dcaf0',
                    data: {!! $deliverd_employees_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },

                {
                    name: '{{ __('phishing.opened_count') }}',
                    color: '#6c757d',
                    data: {!! $campaign_opened_mails_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },
                {
                    name: '{{ __('phishing.clicked_link_count') }}',
                    color: 'red',
                    data: {!! $campaign_clicked_link_mails_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },
                {
                    name: '{{ __('phishing.file_downloaded_count') }}',
                    color: 'yellow',
                    data: {!! $campaign_download_files_mails_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },
                {
                    name: '{{ __('phishing.form_submited_count') }}',
                    color: 'blue',
                    data: {!! $campaign_submit_data_mails_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },


            ],

        })

        // #-3 Groups chart
        Highcharts.chart('groups-chart-container', {
            chart: {
                type: 'column'
            },
            title: {
                text: '{{ __('phishing.Groups_Statistic') }}',
                style: {
                    marginBottom: '120px',
                }
            },
            xAxis: {
                categories: {!! $phish_groups_labels->toJson(JSON_UNESCAPED_UNICODE) !!},
                labels: {
                    formatter: function () {
                        return this.value;
                    }
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: '{{ __('phishing.Groups_Statistic') }}'
                },
                stackLabels: {
                    enabled: true,
                    style: {
                        fontWeight: 'bold',
                        color: ( // theme
                            Highcharts.defaultOptions.title.style &&
                            Highcharts.defaultOptions.title.style.color
                        ) || 'gray'
                    }
                }
            },
            legend: {
                align: 'right',
                x: -30,
                verticalAlign: 'top',
                y: 25,
                floating: true,
                backgroundColor: Highcharts.defaultOptions.legend.backgroundColor || 'white',
                borderColor: '#CCC',
                borderWidth: 1,
                shadow: false
            },
            tooltip: {
                headerFormat: '<b>{point.x}</b>',
                pointFormat: ': {point.stackTotal}'
            },
            plotOptions: {
                column: {
                    stacking: null,
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            series: [
                {
                    name: '{{ __('locale.Employee') }}',
                    color: '#33bcbc',
                    data: {!! $phish_groups_employee_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },

                {
                    name: '{{ __('phishing.Campaigns') }}',
                    color: '#0dcaf0',
                    data: {!! $phish_groups_campaign_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },

                {
                    name: '{{ __('phishing.Deliverd_email') }}',
                    color: '#6c757d',
                    data: {!! $phish_groups_deliverd_email_templates_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },


                {
                    name: '{{ __('phishing.Not_Deliverd_employees') }}',
                    color: 'yellow',
                    data: {!! $phish_groups_not_deliverd_employees_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },

                {
                    name: '{{ __('phishing.Mail_opened') }}',
                    color: 'pink',
                    data: {!! $phish_groups_opened_mails_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },


                {
                    name: '{{ __('phishing.Form_submited') }}',
                    color: 'red',
                    data: {!! $phish_groups_submited_data_in_mails_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },
                {
                    name: '{{ __('phishing.File_download') }}',
                    color: 'brown',
                    data: {!! $phish_groups_downloaded_file_in_mails_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },
                {
                    name: '{{ __('phishing.clicked_link_count') }}',
                    color: 'blue',
                    data: {!! $phish_groups_click_link_in_mails_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },

            ]
        })

        // #-4 Employees chart
        Highcharts.chart('employees-chart-container', {
            chart: {
                type: 'column'
            },
            title: {
                text: '{{ __('phishing.Employees_Statistic') }}',
                style: {
                    marginBottom: '120px',
                }
            },
            xAxis: {
                categories: {!! $employees_labels->toJson(JSON_UNESCAPED_UNICODE) !!},
                labels: {
                    formatter: function () {
                        return this.value;
                    }
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: '{{ __('phishing.Employees_Statistic') }}'
                },
                stackLabels: {
                    enabled: true,
                    style: {
                        fontWeight: 'bold',
                        color: ( // theme
                            Highcharts.defaultOptions.title.style &&
                            Highcharts.defaultOptions.title.style.color
                        ) || 'gray'
                    }
                }
            },
            legend: {
                align: 'right',
                x: -30,
                verticalAlign: 'top',
                y: 25,
                floating: true,
                backgroundColor: Highcharts.defaultOptions.legend.backgroundColor || 'white',
                borderColor: '#CCC',
                borderWidth: 1,
                shadow: false
            },
            tooltip: {
                headerFormat: '<b>{point.x}</b>',
                pointFormat: ': {point.stackTotal}'
            },
            plotOptions: {
                column: {
                    stacking: null,
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            series: [
                {
                    name: '{{ __('phishing.Campaigns') }}',
                    color: '#0dcaf0',
                    data: {!! $employees_campaigns_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },

                {
                    name: '{{ __('phishing.Mail_opened') }}',
                    color: 'pink',
                    data: {!! $employee_opened_mails_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },

                {
                    name: '{{ __('phishing.Form_submited') }}',
                    color: 'red',
                    data: {!! $employee_submited_data_in_mails_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },
                {
                    name: '{{ __('phishing.File_download') }}',
                    color: 'brown',
                    data: {!! $employee_downloaded_file_in_mails_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                },
                {
                    name: '{{ __('phishing.clicked_link_count') }}',
                    color: 'blue',
                    data: {!! $employee_click_links_mails_count->toJson(JSON_UNESCAPED_UNICODE) !!}
                }

            ],

        })

        // ************************************* Training charts *************************************
        Highcharts.chart('training-chart-container', {
            chart: {
                type: 'column'
            },
            title: {
                text: '{{ __('phishing.Training_Employee_Statistic') }}'
            },
            xAxis: {
                categories: {!! $training_labels->toJson(JSON_UNESCAPED_UNICODE) !!},
                labels: {
                    formatter: function () {
                        return this.value;
                    }
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: '{{ __('phishing.Training_Employee_Statistic') }}'
                },
                stackLabels: {
                    enabled: true,
                    style: {
                        fontWeight: 'bold',
                        color: ( // theme
                            Highcharts.defaultOptions.title.style &&
                            Highcharts.defaultOptions.title.style.color
                        ) || 'gray'
                    }
                }
            },
            legend: {
                align: 'right',
                x: -30,
                verticalAlign: 'top',
                y: 25,
                floating: true,
                backgroundColor: Highcharts.defaultOptions.legend.backgroundColor || 'white',
                borderColor: '#CCC',
                borderWidth: 1,
                shadow: false
            },
            tooltip: {
                headerFormat: '<b>{point.x}</b>',
                pointFormat: ': {point.stackTotal}'
            },
            plotOptions: {
                column: {
                    stacking: null,
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            series: [

                {
                    name: '{{ __('phishing.Training_Employee_Delivered') }}',
                    color: 'blue',
                    data: {!! $training_total_recieved_users->toJson(JSON_UNESCAPED_UNICODE) !!}
                },

                {
                    name: '{{ __('phishing.Training_Passed_Employee') }}',
                    color: 'green',
                    data: {!! $training_total_passed_users->toJson(JSON_UNESCAPED_UNICODE) !!}
                },

                {
                    name: '{{ __('phishing.Training_Failed_Employee') }}',
                    color: 'black',
                    data: {!! $training_total_failed_users->toJson(JSON_UNESCAPED_UNICODE) !!}
                },

                {
                    name: '{{ __('phishing.Training_Over_Due_Employee') }}',
                    color: 'red',
                    data: {!! $training_total_overdue_users->toJson(JSON_UNESCAPED_UNICODE) !!}

                },
            ]
        })
    });


    // ************************************* Phishing Modal *************************************
    function openCampaignEmployees(id){
        console.log('campaign id is ' + id)
        getCampaignEmployeesDataTable(id);
        $('#campaign-employees-data-modal').modal('show')
    }

    function getCampaignEmployeesDataTable(campaign_id) {
        if ($.fn.DataTable.isDataTable('.employee-dt-advanced-server-search')) {
            $('.employee-dt-advanced-server-search').DataTable().destroy();
        }

        var table = $('.employee-dt-advanced-server-search').DataTable({
            "language": {
                buttons: {
                    excelHtml5: "{{ __('phishing.Excel') }}",
                    print: "{{ __('phishing.Print') }}",
                    pageLength: "{{ __('phishing.Show') }}",
                    // csvHtml5: "csvHtml5",
                    //pdfHtml5: "pdfHtml5",
                }
            },
            "lengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "{{ __('phishing.All') }}"]
            ],
            dom: 'Bfrtip',
            buttons: [
                'excelHtml5',
                // 'csvHtml5',
                //'pdfHtml5',
                'print',
                'pageLength'
            ],
            lengthChange: true,
            processing: true,
            serverSide: true,
            ajax: {
                url: "{{ route('admin.phishing.campaign.getCampaignData', ':id') }}".replace(':id', campaign_id),
            },
            columns: [
                { name: "name", data: "name", className: "text-center" },
                { name: "email", data: "email", searchable: true, className: "text-center" },
                { name: "delivered", data: "delivered", searchable: true, className: "text-center" },
                { name: "count_of_opened", data: "count_of_opened", searchable: true, className: "text-center" },
                { name: "count_of_clik", data: "count_of_clik", searchable: true, className: "text-center" },
                { name: "count_of_downloaded", data: "count_of_downloaded", searchable: true, className: "text-center" },
                { name: "count_of_submited", data: "count_of_submited", searchable: true, className: "text-center" }
            ],
            "initComplete": function (settings, json) {
                table.buttons().container().appendTo('#dt-btns-employee');
                $('.buttons-excel, .buttons-print, .buttons-collection').addClass('no-transition custom-btn');
                $('.tableAdminOption span, button.dt-button').tooltip();
            }
        });
    }


    // ************************************* Training Modal *************************************
    function openTrainingEmployees(id){
        console.log('campaign id is ' + id)
        getTrainingEmployeesDataTable(id);
        var modal = $('#training-employees-data-modal');
        modal.modal('show');
        // Prevent page scroll
        $('body').addClass('modal-open');
        $('body').css('overflow', 'hidden');
        $('body').css('padding-right', '0');
    }

    function getTrainingEmployeesDataTable(campaign_id) {
        if ($.fn.DataTable.isDataTable('.training-employee-dt-advanced-server-search')) {
            $('.training-employee-dt-advanced-server-search').DataTable().destroy();
        }

        var table = $('.training-employee-dt-advanced-server-search').DataTable({
            "language": {
                buttons: {
                    excelHtml5: "{{ __('phishing.Excel') }}",
                    print: "{{ __('phishing.Print') }}",
                    pageLength: "{{ __('phishing.Show') }}",
                    // csvHtml5: "csvHtml5",
                    //pdfHtml5: "pdfHtml5",
                }
            },
            "lengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "{{ __('phishing.All') }}"]
            ],
            dom: 'Bfrtip',
            buttons: [
                'excelHtml5',
                // 'csvHtml5',
                //'pdfHtml5',
                'print',
                'pageLength'
            ],
            lengthChange: true,
            processing: true,
            serverSide: true,
            ajax: {
                url: "{{ route('admin.phishing.campaign.getEmployeeOfTrainingCampaign', ':id') }}".replace(':id', campaign_id),
            },
            columns: [

                { name: "user_email", data: "user_email",sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "user_name", data: "user_name",sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "training_name", data: "training_name",sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "date_assigned", data: "date_assigned", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "days_until_due", data: "days_until_due", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "score", data: "score", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "passed", data: "passed", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "failed", data: "failed", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "passed_after_overdue", data: "passed_after_overdue", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "overdue", data: "overdue", sortable: true, searchable: true, orderable: true,className: "text-center"},


            ],
            "initComplete": function (settings, json) {
                table.buttons().container().appendTo('#dt-btns-training-employee');
                $('.buttons-excel, .buttons-print, .buttons-collection').addClass('no-transition custom-btn');
                $('.tableAdminOption span, button.dt-button').tooltip();
            }
        });
    }


    // ************************************* Employee Details Modal *************************************
    function openDetailsForEmployee(id){
        console.log('employee id is ' + id)
        getDetailsEmployeeDataTable(id);
        var modal = $('#details-employees-data-modal');
        modal.modal('show');
        // Prevent page scroll
        $('body').addClass('modal-open');
        $('body').css('overflow', 'hidden');
        $('body').css('padding-right', '0');
    }

    // Prevent page scroll when modal closes
    $(document).on('hidden.bs.modal', '.modal', function () {
        $('body').removeClass('modal-open');
        $('body').css('overflow', '');
        $('body').css('padding-right', '');
    });

    function getDetailsEmployeeDataTable(employee_id) {
        if ($.fn.DataTable.isDataTable('.employee-details-phishing-dt-advanced-server-search')) {
            $('.employee-details-phishing-dt-advanced-server-search').DataTable().destroy();
        }

        if ($.fn.DataTable.isDataTable('.employee-details-training-dt-advanced-server-search')) {
            $('.employee-details-training-dt-advanced-server-search').DataTable().destroy();
        }

        // Phishing
        var employeePhishingTable = $('.employee-details-phishing-dt-advanced-server-search').DataTable({
            "language": {
                buttons: {
                    excelHtml5: "Excel",
                    print: "Print",
                    pageLength: "Show",
                    //pdfHtml5: "pdfHtml5",
                }
            },
            "lengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "الكل"]
            ],
            dom: 'Bfrtip',
            buttons: [
                'excelHtml5',
                // 'csvHtml5',
                //'pdfHtml5',
                'print',
                'pageLength'
            ],
            lengthChange: true,
            processing: true,
            serverSide: true,
            ajax: {
                url: "{{ route('admin.phishing.campaign.getEmployeePhishingDataTable',':id') }}".replace(':id',employee_id),
            },
            columns: [
                { name: "campaign_name", data: "campaign_name",sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "template_name", data: "template_name", sortable: true, searchable: true, orderable: true,className: "text-center"},

                { name: "is_opened", data: "is_opened", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "is_link_clicked", data: "is_link_clicked", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "is_file_downloaded", data: "is_file_downloaded", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "is_data_submitted", data: "is_data_submitted", sortable: true, searchable: true, orderable: true,className: "text-center"},
            ],
            "initComplete": function (settings, json) {
                employeePhishingTable.buttons().container().appendTo('#dt-btns-employee-details-phishing');
                $('.buttons-excel, .buttons-print, .buttons-collection').addClass('no-transition custom-btn');
                $('.tableAdminOption span, button.dt-button').tooltip();
            }
        });

        // Training
        var employeeTrainingTable = $('.employee-details-training-dt-advanced-server-search').DataTable({
            "language": {
                buttons: {
                    excelHtml5: "Excel",
                    print: "Print",
                    pageLength: "Show",
                    //pdfHtml5: "pdfHtml5",
                }
            },
            "lengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "الكل"]
            ],
            dom: 'Bfrtip',
            buttons: [
                'excelHtml5',
                // 'csvHtml5',
                //'pdfHtml5',
                'print',
                'pageLength'
            ],
            lengthChange: true,
            processing: true,
            serverSide: true,
            ajax: {
                url: "{{ route('admin.phishing.campaign.getEmployeeTrainingCampaignData',':id') }}".replace(':id',employee_id),
            },
            columns: [
                { name: "campaign_name", data: "campaign_name",sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "training_name", data: "training_name", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "score", data: "score", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "completed", data: "completed", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "overdue", data: "overdue", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "passed", data: "passed", sortable: true, searchable: true, orderable: true,className: "text-center"},
            ],
            "initComplete": function (settings, json) {
                employeeTrainingTable.buttons().container().appendTo('#dt-btns-employee-details-training');
                $('.buttons-excel, .buttons-print, .buttons-collection').addClass('no-transition custom-btn');
                $('.tableAdminOption span, button.dt-button').tooltip();
            }
        });


    }




    $(document).ready(function(){

        // ************************************* Phishing Data Tables *************************************
        var activePhishingTable = $('.active-phishing-dt-advanced-server-search').DataTable({
            "language": {
                buttons: {
                    excelHtml5: "Excel",
                    print: "Print",
                    pageLength: "Show",
                    //pdfHtml5: "pdfHtml5",
                }
            },
            "lengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "الكل"]
            ],
            dom: 'Bfrtip',
            buttons: [
                'excelHtml5',
                // 'csvHtml5',
                //'pdfHtml5',
                'print',
                'pageLength'
            ],
            lengthChange: true,
            processing: true,
            serverSide: true,
            ajax: {
                url: "{{ route('admin.phishing.campaign.getActivePhishingDataTable') }}",
                data: function (d) {
                    d.start_date = $('input[name="start_date"]').val();
                    d.end_date = $('input[name="end_date"]').val();
                }
            },
            columns: [
                { name: "id", data: "id", sortable: false, searchable: false, orderable: false,className: "text-center"},
                { name: "campaign_name", data: "campaign_name",sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "approve", data: "approve", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "campaign_type", data: "campaign_type", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "schedule_date", data: "schedule_date", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "deliverd_email_templates_count", data: "deliverd_email_templates_count", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "opend_count", data: "opend_count", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "downloaded_count", data: "downloaded_count", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "submited_count", data: "submited_count", sortable: true, searchable: true, orderable: true,className: "text-center"},
            ],
            "initComplete": function (settings, json) {
                activePhishingTable.buttons().container().appendTo('#dt-btns-active-phishing');
                $('.buttons-excel, .buttons-print, .buttons-collection').addClass('no-transition custom-btn');
                $('.tableAdminOption span, button.dt-button').tooltip();
            }
        });

        $('.active-phishing-dt-advanced-server-search tbody').on('click', 'tr', function () {
            var data = activePhishingTable.row(this).data();
            if (data) {
                openCampaignEmployees(data.id);
            }
        });

        var archivedPhishingTable = $('.archived-phishing-dt-advanced-server-search').DataTable({
            "language": {
                buttons: {
                    excelHtml5: "Excel",
                    print: "Print",
                    pageLength: "Show",
                    //pdfHtml5: "pdfHtml5",
                }
            },
            "lengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "الكل"]
            ],
            dom: 'Bfrtip',
            buttons: [
                'excelHtml5',
                // 'csvHtml5',
                //'pdfHtml5',
                'print',
                'pageLength'
            ],
            lengthChange: true,
            processing: true,
            serverSide: true,
            ajax: {
                url: "{{ route('admin.phishing.campaign.getArchivedPhishingDataTable') }}",
                data: function (d) {
                    d.start_date = $('input[name="start_date"]').val();
                    d.end_date = $('input[name="end_date"]').val();
                }
            },
            columns: [
                { name: "id", data: "id", sortable: false, searchable: false, orderable: false,className: "text-center"},
                { name: "campaign_name", data: "campaign_name",sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "status", data: "status", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "campaign_type", data: "campaign_type", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "schedule_date", data: "schedule_date", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "deliverd_email_templates_count", data: "deliverd_email_templates_count", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "opend_count", data: "opend_count", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "downloaded_count", data: "downloaded_count", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "submited_count", data: "submited_count", sortable: true, searchable: true, orderable: true,className: "text-center"},
            ],
            "initComplete": function (settings, json) {
                archivedPhishingTable.buttons().container().appendTo('#dt-btns-archived-phishing');
                $('.buttons-excel, .buttons-print, .buttons-collection').addClass('no-transition custom-btn');
                $('.tableAdminOption span, button.dt-button').tooltip();
            }
        });

        $('.archived-phishing-dt-advanced-server-search tbody').on('click', 'tr', function () {
            var data = archivedPhishingTable.row(this).data();
            if (data) {
                openCampaignEmployees(data.id);
            }
        });


        // ************************************* Training Data Tables *************************************
        var activeTable = $('.active-training-dt-advanced-server-search').DataTable({
            "language": {
                buttons: {
                    excelHtml5: "Excel",
                    print: "Print",
                    pageLength: "Show",
                    //pdfHtml5: "pdfHtml5",
                }
            },
            "lengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "الكل"]
            ],
            dom: 'Bfrtip',
            buttons: [
                'excelHtml5',
                // 'csvHtml5',
                //'pdfHtml5',
                'print',
                'pageLength'
            ],
            lengthChange: true,
            processing: true,
            serverSide: true,
            ajax: {
                url: "{{ route('admin.phishing.campaign.getActiveTrainingCampaignData') }}",
                data: function (d) {
                    d.start_date = $('input[name="start_date"]').val();
                    d.end_date = $('input[name="end_date"]').val();
                }
            },
            columns: [
                { name: "id", data: "id", sortable: false, searchable: false, orderable: false,className: "text-center"},
                { name: "campaign_name", data: "campaign_name",sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "status", data: "status", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "campaign_type", data: "campaign_type", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "schedule_date", data: "schedule_date", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "employee_count", data: "employee_count", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "assigned", data: "assigned", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "passed", data: "passed", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "failed", data: "failed", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "passed_after_overdue", data: "passed_after_overdue", sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "overdue", data: "overdue", sortable: true, searchable: true, orderable: true,className: "text-center"},
            ],
            "initComplete": function (settings, json) {
                activeTable.buttons().container().appendTo('#dt-btns-active-training');
                $('.buttons-excel, .buttons-print, .buttons-collection').addClass('no-transition custom-btn');
                $('.tableAdminOption span, button.dt-button').tooltip();
            }
        });

        $('.active-training-dt-advanced-server-search tbody').on('click', 'tr', function () {
            var data = activeTable.row(this).data();
            if (data) {
                openTrainingEmployees(data.id);
            }
        });

        var archivedTable = $('.archived-training-dt-advanced-server-search').DataTable({
            "language": {
                buttons: {
                    excelHtml5: "Excel",
                    print: "Print",
                    pageLength: "Show",
                    //pdfHtml5: "pdfHtml5",
                }
            },
            "lengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "الكل"]
            ],
            dom: 'Bfrtip',
            buttons: [
                'excelHtml5',
                // 'csvHtml5',
                //'pdfHtml5',
                'print',
                'pageLength'
            ],
            lengthChange: true,
            processing: true,
            serverSide: true,
            ajax: {
                url: "{{ route('admin.phishing.campaign.getArchivedTrainingCampaignData') }}",
                data: function (d) {
                    d.start_date = $('input[name="start_date"]').val();
                    d.end_date = $('input[name="end_date"]').val();
                }
            },
            columns: [
                { name: "id", data: "id", sortable: false, searchable: false, orderable: false,className: "text-center"},
                { name: "campaign_name", data: "campaign_name",sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "status", data: "status",sortable: true, searchable: true, orderable: true,className: "text-center" },
                { name: "campaign_type", data: "campaign_type",sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "schedule_date", data: "schedule_date",sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "employee_count", data: "employee_count",sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "assigned", data: "assigned",sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "completed", data: "completed",sortable: true, searchable: true, orderable: true,className: "text-center"},
                { name: "overdue", data: "overdue",sortable: true, searchable: true, orderable: true,className: "text-center"},
            ],
            "initComplete": function (settings, json) {
                archivedTable.buttons().container().appendTo('#dt-btns-archived-training');
                $('.buttons-excel, .buttons-print, .buttons-collection').addClass('no-transition custom-btn');
                $('.tableAdminOption span, button.dt-button').tooltip();
            }
        });

        $('.archived-training-dt-advanced-server-search tbody').on('click', 'tr', function () {
            var data = archivedTable.row(this).data();
            if (data) {
                openTrainingEmployees(data.id);
            }
        });

        // ************************************* Employee Statistics Data Tables *************************************
        var employeeStatisticTable = $('.employee-statistics-dt-advanced-server-search').DataTable({
            "language": {
                buttons: {
                    excelHtml5: "Excel",
                    print: "Print",
                    pageLength: "Show",
                    //pdfHtml5: "pdfHtml5",
                }
            },
            "lengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "الكل"]
            ],
            dom: 'Bfrtip',
            buttons: [
                'excelHtml5',
                // 'csvHtml5',
                //'pdfHtml5',
                'print',
                'pageLength'
            ],
            lengthChange: true,
            processing: true,
            serverSide: true,
            ajax: {
                url: "{{ route('admin.phishing.campaign.getPhisedEmployee') }}",
                data: function (d) {
                    d.start_date = $('input[name="start_date"]').val();
                    d.end_date = $('input[name="end_date"]').val();
                }
            },
            columns: [
                { name: "id", data: "employee_id", searchable: true,className:'text-center' },
                { name: "email", data: "email", searchable: true,className:'text-center' },
                { name: "name", data: "name",searchable: true,className:'text-center' },
                { name: "average_percentage", data: "average_percentage",searchable: true,className:'text-center'},
            ],
            "initComplete": function (settings, json) {
                employeeStatisticTable.buttons().container().appendTo('#dt-btns-employee-statistics');
                $('.buttons-excel, .buttons-print, .buttons-collection').addClass('no-transition custom-btn');
                $('.tableAdminOption span, button.dt-button').tooltip();
            }
        });

        $('.employee-statistics-dt-advanced-server-search tbody').on('click', 'tr', function () {
            var data = employeeStatisticTable.row(this).data();
            if (data) {
                openDetailsForEmployee(data.employee_id);
            }
        });

    })

</script>
@endsection

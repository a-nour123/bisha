<?php

return array(
    'domains' => 'Domains',
);

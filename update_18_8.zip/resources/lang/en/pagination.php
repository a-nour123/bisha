<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Pagination Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the paginator library to build
    | the simple pagination links. You are free to change them to anything
    | you want to customize your views to better match your application.
    |
    */

    'previous' => '&laquo; Previous',
    'next' => 'Next &raquo;',
    'Pagination Navigation' => 'Pagination Navigation',
    'Showing' => 'Showing',
    'to' => 'to',
    'of' => 'of',
    'results' => 'results',
    'Go to page :page' => 'Go to page :page',
];

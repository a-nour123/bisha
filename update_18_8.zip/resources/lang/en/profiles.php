<?php

return array(
    'configuretion' => 'Configuretion',
);

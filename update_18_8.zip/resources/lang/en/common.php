<?php

return array(
    'SomethingWentWrong' => 'Something Went Wrong',
);

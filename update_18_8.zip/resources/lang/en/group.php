<?php

return array(
    'Name' => 'Name',
    'Actions' => 'Actions',
);

<?php

namespace App\Console\Commands;

use App\Jobs\SendCampaignEmailsJob;
use Illuminate\Console\Command;
use App\Models\PhishingCampaign;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;

class SendCampaignScheduledEmails extends Command
{
    protected $signature = 'emails:send-campaign-scheduled';
    protected $description = 'Send scheduled emails for campaigns with delivery_type "setup"';

    public function __construct()
    {
        parent::__construct();
    }

    public function handle()
    {
        try {
            // Get all approved campaigns with delivery_type 'setup'
            $allCampaigns = PhishingCampaign::with(['employees', 'emailTemplates.senderProfile', 'emailTemplates.website'])
                ->where('delivery_type', 'setup')
                ->where('approve', 1)
                ->whereIn('campaign_type', ['simulated_phishing', 'simulated_phishing_and_security_awareness'])
                ->get();

            $campaignsToSend = collect();

            foreach ($allCampaigns as $campaign) {
                // Use campaign timezone if available, otherwise use app timezone
                $timezone = $campaign->time_zone ?? config('app.timezone');
                $now = now($timezone);
                $currentDate = $now->toDateString();
                $currentTime = $now->toTimeString();

                // Check if campaign has expired
                if ($campaign->expire_after && $campaign->expire_after < $currentDate) {
                    Log::info('Campaign expired, skipping', [
                        'campaign_id' => $campaign->id,
                        'campaign_name' => $campaign->campaign_name,
                        'expire_after' => $campaign->expire_after
                    ]);
                    continue;
                }

                // Check date range
                if ($campaign->schedule_date_from > $currentDate || $campaign->schedule_date_to < $currentDate) {
                    continue;
                }

                // Check campaign frequency
                $shouldSend = false;

                if ($campaign->campaign_frequency === 'oneOf' || !$campaign->campaign_frequency) {
                    // One-time campaign: check if not already sent
                    if ($campaign->delivery_status == 0) {
                        // Check if current time is within schedule time range
                        if ($campaign->schedule_time_from <= $currentTime && $campaign->schedule_time_to >= $currentTime) {
                            $shouldSend = true;
                        }
                    }
                } else {
                    // Recurring campaign: check if it's time to send
                    $lastSentDate = $this->getLastSentDate($campaign);
                    
                    if ($campaign->campaign_frequency === 'weekly') {
                        // Send if last sent was more than 7 days ago, or never sent
                        if (!$lastSentDate || $lastSentDate->copy()->addDays(7)->lte($now)) {
                            // Check if current time matches schedule_time_from (send at specific time)
                            if ($campaign->schedule_time_from <= $currentTime && 
                                $currentTime <= $this->addMinutes($campaign->schedule_time_from, 5)) { // 5 minutes window
                                $shouldSend = true;
                            }
                        }
                    } elseif ($campaign->campaign_frequency === 'monthly') {
                        // Send if last sent was more than 1 month ago, or never sent
                        if (!$lastSentDate || $lastSentDate->copy()->addMonth()->lte($now)) {
                            if ($campaign->schedule_time_from <= $currentTime && 
                                $currentTime <= $this->addMinutes($campaign->schedule_time_from, 5)) {
                                $shouldSend = true;
                            }
                        }
                    } elseif ($campaign->campaign_frequency === 'quarterly') {
                        // Send if last sent was more than 3 months ago, or never sent
                        if (!$lastSentDate || $lastSentDate->copy()->addMonths(3)->lte($now)) {
                            if ($campaign->schedule_time_from <= $currentTime && 
                                $currentTime <= $this->addMinutes($campaign->schedule_time_from, 5)) {
                                $shouldSend = true;
                            }
                        }
                    }
                }

                if ($shouldSend) {
                    $campaignsToSend->push($campaign);
                }
            }

            if ($campaignsToSend->isEmpty()) {
                $this->info('No scheduled campaigns to send at this time.');
                return 0;
            }

            $sentCount = 0;
            $failedCount = 0;

            foreach ($campaignsToSend as $campaign) {
                try {
                    // Validate that campaign has employees and email templates
                    if ($campaign->employees->isEmpty()) {
                        Log::warning('Campaign has no employees', [
                            'campaign_id' => $campaign->id,
                            'campaign_name' => $campaign->campaign_name
                        ]);
                        continue;
                    }

                    if ($campaign->emailTemplates->isEmpty()) {
                        Log::warning('Campaign has no email templates', [
                            'campaign_id' => $campaign->id,
                            'campaign_name' => $campaign->campaign_name
                        ]);
                        continue;
                    }

                    // For recurring campaigns, reset is_delivered flags before sending
                    if (in_array($campaign->campaign_frequency, ['weekly', 'monthly', 'quarterly'])) {
                        // Reset is_delivered for recurring campaigns to allow re-sending
                        DB::table('phishing_campaign_employee_list')
                            ->where('campaign_id', $campaign->id)
                            ->update(['is_delivered' => 0]);
                        
                        DB::table('phishing_campaign_email_template')
                            ->where('campaign_id', $campaign->id)
                            ->update(['is_delivered' => 0]);
                    }

                    // Update status to inProgress before sending
                    $campaign->update(['status' => 'inProgress']);

                    // Dispatch the job with correct parameters: campaign, employees, emailTemplates
                    SendCampaignEmailsJob::dispatch($campaign, $campaign->employees, $campaign->emailTemplates);

                    $sentCount++;
                    $this->info("Dispatched email job for campaign: {$campaign->campaign_name} (ID: {$campaign->id})");

                    Log::info('Scheduled campaign email job dispatched', [
                        'campaign_id' => $campaign->id,
                        'campaign_name' => $campaign->campaign_name,
                        'campaign_frequency' => $campaign->campaign_frequency,
                        'employees_count' => $campaign->employees->count(),
                        'templates_count' => $campaign->emailTemplates->count()
                    ]);

                } catch (\Exception $e) {
                    $failedCount++;
                    Log::error('Error dispatching scheduled campaign email job', [
                        'campaign_id' => $campaign->id,
                        'campaign_name' => $campaign->campaign_name,
                        'error' => $e->getMessage(),
                        'trace' => $e->getTraceAsString()
                    ]);
                    $this->error("Failed to dispatch email job for campaign: {$campaign->campaign_name} (ID: {$campaign->id})");
                }
            }

            $this->info("Scheduled emails processing completed. Sent: {$sentCount}, Failed: {$failedCount}");

            Log::info('Scheduled emails command completed', [
                'total_campaigns' => $campaignsToSend->count(),
                'sent_count' => $sentCount,
                'failed_count' => $failedCount
            ]);

            return 0;

        } catch (\Exception $e) {
            Log::error('Critical error in SendCampaignScheduledEmails command', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            $this->error('An error occurred while processing scheduled emails: ' . $e->getMessage());
            return 1;
        }
    }

    /**
     * Get the last sent date for a campaign
     */
    private function getLastSentDate($campaign)
    {
        // Try to get from tracking table
        $lastTracking = DB::table('phishing_mail_trackings')
            ->where('campaign_id', $campaign->id)
            ->orderBy('created_at', 'desc')
            ->first();

        if ($lastTracking) {
            return \Carbon\Carbon::parse($lastTracking->created_at);
        }

        // If no tracking found and delivery_status is 1, use schedule_date_from as last sent
        if ($campaign->delivery_status == 1 && $campaign->schedule_date_from) {
            return \Carbon\Carbon::parse($campaign->schedule_date_from);
        }

        return null;
    }

    /**
     * Add minutes to a time string
     */
    private function addMinutes($timeString, $minutes)
    {
        $time = \Carbon\Carbon::parse($timeString);
        return $time->addMinutes($minutes)->toTimeString();
    }
}

<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use TCPDF_FONTS;

class InstallCertificateFonts extends Command
{
    protected $signature = 'certificates:install-fonts';

    protected $description = 'Convert Arabic certificate TTFs for TCPDF (fixes dgheaven/cairo missing font errors on server)';

    public function handle(): int
    {
        if (!defined('K_TCPDF_THROW_EXCEPTION_ERROR')) {
            define('K_TCPDF_THROW_EXCEPTION_ERROR', true);
        }

        $ttfMap = [
            'cairo' => public_path('fonts/arabic/Cairo.ttf'),
            'tajawal' => public_path('fonts/arabic/Tajawal-Regular.ttf'),
            'amiri' => public_path('fonts/arabic/Amiri-Regular.ttf'),
            'almarai' => public_path('fonts/arabic/Almarai-Regular.ttf'),
            'elmessiri' => public_path('fonts/arabic/ElMessiri.ttf'),
            'reemkufi' => public_path('fonts/arabic/ReemKufi.ttf'),
            'notokufiarabic' => public_path('fonts/arabic/NotoKufiArabic.ttf'),
            'notonaskharabic' => public_path('fonts/arabic/NotoNaskhArabic.ttf'),
            'scheherazadenew' => public_path('fonts/arabic/ScheherazadeNew-Regular.ttf'),
            'dgheaven' => public_path('fonts/arabic/DGHeaven-Regular.ttf'),
            'dgheavenb' => public_path('fonts/arabic/DGHeaven-Bold.ttf'),
        ];

        $storageDir = storage_path('app/tcpdf-fonts');
        $vendorDir = defined('K_PATH_FONTS') && K_PATH_FONTS
            ? rtrim(K_PATH_FONTS, '/\\')
            : base_path('vendor/tecnickcom/tcpdf/fonts');

        foreach ([$storageDir, $vendorDir] as $dir) {
            if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) {
                $this->error("Cannot create directory: {$dir}");
                return self::FAILURE;
            }
            if (!is_writable($dir)) {
                $this->error("Directory is not writable: {$dir}");
                $this->line('Fix with: chmod -R ug+rwx ' . $dir);
                return self::FAILURE;
            }
        }

        $this->info('Storage fonts dir: ' . $storageDir);
        $this->info('TCPDF fonts dir:   ' . $vendorDir);
        $this->newLine();

        $ok = 0;
        $failed = 0;

        foreach ($ttfMap as $label => $ttfPath) {
            if (!is_file($ttfPath)) {
                $this->warn("[SKIP] Missing TTF: {$ttfPath}");
                $failed++;
                continue;
            }

            try {
                $fontName = TCPDF_FONTS::addTTFfont(
                    $ttfPath,
                    'TrueTypeUnicode',
                    '',
                    96,
                    $storageDir . DIRECTORY_SEPARATOR
                );

                if (!$fontName) {
                    $this->error("[FAIL] {$label}: addTTFfont returned empty");
                    $failed++;
                    continue;
                }

                foreach ([$fontName . '.php', $fontName . '.z', $fontName . '.ctg.z'] as $artifact) {
                    $src = $storageDir . DIRECTORY_SEPARATOR . $artifact;
                    $dst = $vendorDir . DIRECTORY_SEPARATOR . $artifact;
                    if (is_file($src)) {
                        if (!@copy($src, $dst)) {
                            $this->error("[FAIL] Could not copy {$artifact} to vendor fonts dir");
                            $failed++;
                            continue 2;
                        }
                    }
                }

                $vendorPhp = $vendorDir . DIRECTORY_SEPARATOR . $fontName . '.php';
                if (!is_file($vendorPhp)) {
                    $this->error("[FAIL] {$label}: {$fontName}.php missing in vendor fonts after copy");
                    $failed++;
                    continue;
                }

                $this->info("[OK] {$label} => {$fontName}");
                $ok++;
            } catch (\Throwable $e) {
                $this->error("[FAIL] {$label}: " . $e->getMessage());
                $failed++;
            }
        }

        $this->newLine();
        $this->info("Done. Installed={$ok}, Failed={$failed}");

        if ($failed > 0) {
            $this->warn('If vendor copy failed, run as the web server user, e.g.:');
            $this->line('  sudo -u www-data php artisan certificates:install-fonts');
            return self::FAILURE;
        }

        $this->info('Preview should work now. Hard-refresh the design page and try again.');
        return self::SUCCESS;
    }
}

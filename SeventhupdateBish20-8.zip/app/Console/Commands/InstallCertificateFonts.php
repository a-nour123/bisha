<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use TCPDF_FONTS;

class InstallCertificateFonts extends Command
{
    protected $signature = 'certificates:install-fonts';

    protected $description = 'Convert Arabic certificate TTFs for TCPDF (fixes dgheaven/cairo missing font errors on server)';

    public function handle(): int
    {
        $ttfMap = [
            'cairo' => public_path('fonts/arabic/Cairo.ttf'),
            'tajawal' => public_path('fonts/arabic/Tajawal-Regular.ttf'),
            'amiri' => public_path('fonts/arabic/Amiri-Regular.ttf'),
            'almarai' => public_path('fonts/arabic/Almarai-Regular.ttf'),
            'elmessiri' => public_path('fonts/arabic/ElMessiri.ttf'),
            'reemkufi' => public_path('fonts/arabic/ReemKufi.ttf'),
            'notokufiarabic' => public_path('fonts/arabic/NotoKufiArabic.ttf'),
            'notonaskharabic' => public_path('fonts/arabic/NotoNaskhArabic.ttf'),
            'scheherazadenew' => public_path('fonts/arabic/ScheherazadeNew-Regular.ttf'),
            'dgheaven' => public_path('fonts/arabic/DGHeaven-Regular.ttf'),
            'dgheavenb' => public_path('fonts/arabic/DGHeaven-Bold.ttf'),
        ];

        $storageDir = storage_path('app/tcpdf-fonts');
        $vendorDir = defined('K_PATH_FONTS') && K_PATH_FONTS
            ? rtrim(K_PATH_FONTS, '/\\')
            : base_path('vendor/tecnickcom/tcpdf/fonts');

        $writableTargets = [];

        foreach ([$vendorDir, $storageDir] as $dir) {
            if (!is_dir($dir)) {
                @mkdir($dir, 0775, true);
            }

            if (is_dir($dir) && is_writable($dir)) {
                $writableTargets[] = $dir;
                $this->info('Writable: ' . $dir);
            } else {
                $this->warn('Not writable (skip): ' . $dir);
            }
        }

        if (empty($writableTargets)) {
            $this->error('No writable font directory found.');
            $this->newLine();
            $this->line('Run these commands on the server (use your web user if needed):');
            $this->line('  sudo mkdir -p ' . $storageDir);
            $this->line('  sudo chown -R $(whoami):$(whoami) ' . $storageDir . ' ' . $vendorDir);
            $this->line('  sudo chmod -R ug+rwx ' . $storageDir . ' ' . $vendorDir);
            $this->line('  # or as web user:');
            $this->line('  sudo chown -R apache:apache ' . $storageDir . ' ' . $vendorDir);
            $this->line('  sudo -u apache php artisan certificates:install-fonts');
            return self::FAILURE;
        }

        // Prefer vendor TCPDF fonts dir (required at runtime). Fall back to storage.
        $primaryDir = in_array($vendorDir, $writableTargets, true)
            ? $vendorDir
            : $writableTargets[0];

        $this->info('Primary output dir: ' . $primaryDir);
        $this->newLine();

        $ok = 0;
        $failed = 0;

        foreach ($ttfMap as $label => $ttfPath) {
            if (!is_file($ttfPath)) {
                $this->warn("[SKIP] Missing TTF: {$ttfPath}");
                $failed++;
                continue;
            }

            try {
                $fontName = TCPDF_FONTS::addTTFfont(
                    $ttfPath,
                    'TrueTypeUnicode',
                    '',
                    96,
                    rtrim($primaryDir, '/\\') . DIRECTORY_SEPARATOR
                );

                if (!$fontName) {
                    $this->error("[FAIL] {$label}: addTTFfont returned empty");
                    $failed++;
                    continue;
                }

                // Mirror artifacts into every writable target
                foreach ($writableTargets as $targetDir) {
                    if ($targetDir === $primaryDir) {
                        continue;
                    }
                    foreach ([$fontName . '.php', $fontName . '.z', $fontName . '.ctg.z'] as $artifact) {
                        $src = rtrim($primaryDir, '/\\') . DIRECTORY_SEPARATOR . $artifact;
                        $dst = rtrim($targetDir, '/\\') . DIRECTORY_SEPARATOR . $artifact;
                        if (is_file($src)) {
                            @copy($src, $dst);
                        }
                    }
                }

                $phpFile = rtrim($primaryDir, '/\\') . DIRECTORY_SEPARATOR . $fontName . '.php';
                if (!is_file($phpFile)) {
                    $this->error("[FAIL] {$label}: {$fontName}.php was not created");
                    $failed++;
                    continue;
                }

                $this->info("[OK] {$label} => {$fontName}");
                $ok++;
            } catch (\Throwable $e) {
                $this->error("[FAIL] {$label}: " . $e->getMessage());
                $failed++;
            }
        }

        $this->newLine();
        $this->info("Done. Installed={$ok}, Failed={$failed}");

        $vendorPhp = rtrim($vendorDir, '/\\') . DIRECTORY_SEPARATOR . 'dgheaven.php';
        if (is_file($vendorPhp)) {
            $this->info('Verified: vendor/.../fonts/dgheaven.php exists');
        } elseif (in_array($vendorDir, $writableTargets, true)) {
            $this->warn('dgheaven.php not found in vendor fonts dir — preview may still fail');
        } else {
            $this->warn('Vendor fonts dir not writable. Make it writable then re-run this command:');
            $this->line('  sudo chmod -R ug+rwx ' . $vendorDir);
            $this->line('  sudo chown -R apache:apache ' . $vendorDir);
        }

        return $failed > 0 ? self::FAILURE : self::SUCCESS;
    }
}
